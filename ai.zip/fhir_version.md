# Fhir Version - NCPI FHIR Implementation Guide v2 v0.2.0

* [**Table of Contents**](toc.md)
* **Fhir Version**

## Fhir Version

At this time we are focussing the majority of our efforts on mapping the research study components to R4, with the release of R5 in February 2023 we are including them in this iteration but on an experimental basis. Please see the research study documentation for in-depth mappings on a R5 version as well as a R4 version and the necessary extensions needed to ensure interoperability. We are not recommending or mandating an upgrade of your local FHIR instance at this point, if this changes we will communicate the next steps and rationale to all stakeholders.

